import pandas as pd
import requests
import math
from datetime import datetime
from tqdm import tqdm

#Configuration
HERE_API_KEY = "YOUR_HERE_API_KEY"  
USE_HERE_API = False  
OUTPUT_PATH = "results/basecase_results.csv"

#Distance Calculation
def distance(p1, p2):
    """Approximate distance using Haversine formula"""
    R = 6371
    lat1, lon1 = math.radians(p1[0]), math.radians(p1[1])
    lat2, lon2 = math.radians(p2[0]), math.radians(p2[1])
    dlat, dlon = lat2 - lat1, lon2 - lon1
    a = math.sin(dlat/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    return 2 * R * math.asin(math.sqrt(a))

def get_travel_time(start, end):
    """Use HERE API (or mock travel time)"""
    if not USE_HERE_API:
        # Assume 40 km/h average speed
        dist = distance(start, end)
        return dist / 40 * 60  # minutes
    url = (
        f"https://router.hereapi.com/v8/routes"
        f"?transportMode=car&origin={start[0]},{start[1]}"
        f"&destination={end[0]},{end[1]}&return=summary&apikey={HERE_API_KEY}"
    )
    res = requests.get(url).json()
    return res["routes"][0]["sections"][0]["summary"]["duration"] / 60  # minutes

#Simulation Logic

def run_base_case(jobs_file, carriers_file):
    jobs = pd.read_csv(jobs_file)
    carriers = pd.read_csv(carriers_file)
    results = []

    for _, job in tqdm(jobs.iterrows(), total=len(jobs)):
        available = carriers[carriers["status"] == "available"]
        if available.empty:
            print(f"No carriers available for job {job.job_id}")
            continue

        #find nearest available carrier
        available["dist_km"] = available.apply(
            lambda c: distance(
                (c.current_lat, c.current_lon),
                (job.pickup_lat, job.pickup_lon),
            ),
            axis=1,
        )
        nearest = available.loc[available["dist_km"].idxmin()]

        # estimate travel time
        travel_time = get_travel_time(
            (nearest.current_lat, nearest.current_lon),
            (job.pickup_lat, job.pickup_lon),
        )

        #mark carrier as busy (simple base case: they stay busy forever)
        carriers.loc[carriers.carrier_id == nearest.carrier_id, "status"] = "busy"

        #record result
        results.append({
            "job_id": job.job_id,
            "carrier_id": nearest.carrier_id,
            "pickup_distance_km": nearest.dist_km,
            "est_travel_time_min": round(travel_time, 2),
            "assignment_time": datetime.utcnow().isoformat()
        })

    results_df = pd.DataFrame(results)
    results_df.to_csv(OUTPUT_PATH, index=False)
    print(f"\nSaved results to {OUTPUT_PATH}")
    print(results_df)

if __name__ == "__main__":
    run_base_case("data/jobs.csv", "data/carriers.csv")
